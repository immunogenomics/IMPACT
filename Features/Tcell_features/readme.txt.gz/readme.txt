     (\_/)
     (0.0)
     (___)O
 ------------
|Instructions|
 ------------

-------------------------------------------------
-- IMPACT Features readme --
-------------------------------------------------

In this directory, I have features from Finucane et al 2015 and all peak
called features from my own collection. 


